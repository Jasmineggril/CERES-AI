/**
 * CERES AI — Página de Configurações
 * Coloque este arquivo em: client/src/pages/Settings.tsx
 *
 * No App.tsx, substitua a linha do /settings por:
 *   import Settings from "@/pages/Settings";
 *   ...
 *   <Route path="/settings" component={() => <ProtectedRoute component={Settings} />} />
 */

import { useState, useRef, useEffect } from "react";
import { Layout } from "@/components/Layout";
import { useAuthStatus } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import {
  User, Bell, Palette, Shield, Plug,
  Camera, Trash2, Eye, EyeOff, Copy,
  RefreshCw, Download, LogOut, KeyRound,
  Smartphone, Globe, Mail, MessageSquare,
  Sun, Moon, Monitor, AlertTriangle
} from "lucide-react";

// ─── tipos ───────────────────────────────────────────────────────────────────

interface ProfileData {
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  bio: string;
  phone: string;
  organization: string;
  state: string;
  photoUrl: string;
}

interface NotifSettings {
  emailAlerts: boolean;
  emailReports: boolean;
  emailUpdates: boolean;
  pushAlerts: boolean;
  pushReminders: boolean;
  smsAlerts: boolean;
  weeklyDigest: boolean;
  monthlyReport: boolean;
}

interface AppearSettings {
  theme: "light" | "dark" | "system";
  density: "compact" | "normal" | "spacious";
  language: string;
  dateFormat: string;
  timezone: string;
}

// ─── helpers ─────────────────────────────────────────────────────────────────

function load<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : fallback;
  } catch {
    return fallback;
  }
}

function save(key: string, value: unknown) {
  localStorage.setItem(key, JSON.stringify(value));
}

function passwordStrength(pw: string): { score: number; label: string; color: string } {
  if (!pw) return { score: 0, label: "", color: "" };
  let score = 0;
  if (pw.length >= 8) score++;
  if (/[A-Z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  const map = [
    { label: "Muito fraca", color: "#ef4444" },
    { label: "Fraca", color: "#f97316" },
    { label: "Razoável", color: "#eab308" },
    { label: "Forte", color: "#22c55e" },
    { label: "Muito forte", color: "#0F5132" },
  ];
  return { score, ...map[score] };
}

// ─── componentes menores ──────────────────────────────────────────────────────

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2"
      style={{
        backgroundColor: checked ? "#0F5132" : "#d1d5db",
        boxShadow: checked ? "0 0 0 2px #0F513230" : undefined,
      }}
    >
      <span
        className="pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow-lg transition-transform duration-200"
        style={{ transform: checked ? "translateX(20px)" : "translateX(0)" }}
      />
    </button>
  );
}

function SectionCard({ title, description, children }: {
  title: string; description?: string; children: React.ReactNode;
}) {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-50">
        <h3 className="text-base font-semibold text-gray-900">{title}</h3>
        {description && <p className="text-sm text-gray-500 mt-0.5">{description}</p>}
      </div>
      <div className="p-6">{children}</div>
    </div>
  );
}

// ─── tabs ─────────────────────────────────────────────────────────────────────

const TABS = [
  { id: "perfil",        icon: User,    label: "Perfil" },
  { id: "notificacoes",  icon: Bell,    label: "Notificações" },
  { id: "aparencia",     icon: Palette, label: "Aparência" },
  { id: "seguranca",     icon: Shield,  label: "Segurança" },
  { id: "integracoes",   icon: Plug,    label: "Integrações" },
] as const;

type TabId = typeof TABS[number]["id"];

// ─── Settings page ────────────────────────────────────────────────────────────

export default function Settings() {
  const { data: authUser } = useAuthStatus();
  const { toast } = useToast();

  const [activeTab, setActiveTab] = useState<TabId>("perfil");

  // Profile
  const defaultProfile: ProfileData = {
    firstName: authUser?.firstName ?? authUser?.username ?? "",
    lastName: authUser?.lastName ?? "",
    email: authUser?.email ?? "",
    role: "Analista Ambiental",
    bio: "",
    phone: "",
    organization: "CERES AI",
    state: "DF",
    photoUrl: authUser?.profileImageUrl ?? "",
  };
  const [profile, setProfile] = useState<ProfileData>(() => load("ceres:profile", defaultProfile));
  const [saved, setSaved] = useState<ProfileData>(profile);
  const [dirty, setDirty] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const setField = (field: keyof ProfileData, value: string) => {
    setProfile(p => { const n = { ...p, [field]: value }; setDirty(JSON.stringify(n) !== JSON.stringify(saved)); return n; });
  };

  const handleSaveProfile = () => {
    save("ceres:profile", profile);
    setSaved(profile);
    setDirty(false);
    toast({ title: "Perfil atualizado", description: "Suas informações foram salvas com sucesso." });
  };

  const handleDiscard = () => {
    setProfile(saved);
    setDirty(false);
  };

  const handlePhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "Arquivo muito grande", description: "Máximo 5 MB.", variant: "destructive" });
      return;
    }
    const reader = new FileReader();
    reader.onload = ev => setField("photoUrl", ev.target?.result as string);
    reader.readAsDataURL(file);
  };

  const initials = `${profile.firstName[0] ?? ""}${profile.lastName[0] ?? ""}`.toUpperCase() || "U";

  // Notificações
  const [notif, setNotif] = useState<NotifSettings>(() => load("ceres:notif", {
    emailAlerts: true, emailReports: true, emailUpdates: false,
    pushAlerts: true, pushReminders: false,
    smsAlerts: false, weeklyDigest: true, monthlyReport: true,
  }));
  const toggleNotif = (k: keyof NotifSettings) => {
    setNotif(n => { const u = { ...n, [k]: !n[k] }; save("ceres:notif", u); return u; });
    toast({ title: "Preferência salva" });
  };

  // Aparência
  const [appear, setAppear] = useState<AppearSettings>(() => load("ceres:appear", {
    theme: "light", density: "normal", language: "pt-BR", dateFormat: "dd/MM/yyyy", timezone: "America/Sao_Paulo",
  }));
  const setAppearField = <K extends keyof AppearSettings>(k: K, v: AppearSettings[K]) => {
    setAppear(a => { const u = { ...a, [k]: v }; save("ceres:appear", u); return u; });
    toast({ title: "Aparência atualizada" });
  };

  // Segurança
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [currentPw, setCurrentPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const strength = passwordStrength(newPw);

  const handleChangePassword = () => {
    if (!currentPw) { toast({ title: "Informe a senha atual", variant: "destructive" }); return; }
    if (newPw.length < 8) { toast({ title: "Mínimo 8 caracteres", variant: "destructive" }); return; }
    if (newPw !== confirmPw) { toast({ title: "As senhas não coincidem", variant: "destructive" }); return; }
    setCurrentPw(""); setNewPw(""); setConfirmPw("");
    toast({ title: "Senha alterada com sucesso" });
  };

  // Integrações
  const [apiKey, setApiKey] = useState(() => load("ceres:apikey", "cer_" + Math.random().toString(36).slice(2, 18)));
  const [webhook, setWebhook] = useState(() => load("ceres:webhook", ""));
  const [slackConnected, setSlackConnected] = useState(() => load("ceres:slack", false));
  const [sheetsConnected, setSheetsConnected] = useState(() => load("ceres:sheets", false));

  const copyApiKey = () => { navigator.clipboard.writeText(apiKey); toast({ title: "Chave copiada" }); };
  const regenApiKey = () => {
    const k = "cer_" + Math.random().toString(36).slice(2, 18);
    setApiKey(k); save("ceres:apikey", k);
    toast({ title: "Nova chave gerada" });
  };
  const saveWebhook = () => { save("ceres:webhook", webhook); toast({ title: "Webhook salvo" }); };

  // ─── render ─────────────────────────────────────────────────────────────────

  return (
    <Layout>
      {/* Cabeçalho */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold font-display" style={{ color: "#0F5132" }}>
          Configurações
        </h1>
        <p className="text-sm text-gray-500 mt-1">
          Gerencie sua conta, notificações, segurança e integrações.
        </p>
      </div>

      {/* Banner de alterações não salvas */}
      {dirty && activeTab === "perfil" && (
        <div className="mb-4 flex items-center justify-between rounded-xl border px-4 py-3 text-sm font-medium"
          style={{ background: "#FFFBEB", borderColor: "#C9A227", color: "#92400e" }}>
          <span style={{ color: "#C9A227" }}>⚠ Você tem alterações não salvas no perfil</span>
          <div className="flex gap-2">
            <button onClick={handleDiscard}
              className="px-3 py-1 rounded-lg border text-gray-600 bg-white hover:bg-gray-50 transition-colors text-xs">
              Descartar
            </button>
            <button onClick={handleSaveProfile}
              className="px-3 py-1 rounded-lg text-white text-xs transition-colors"
              style={{ background: "#0F5132" }}>
              Salvar
            </button>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-1 flex gap-1 mb-6 overflow-x-auto">
        {TABS.map(tab => {
          const active = activeTab === tab.id;
          return (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all whitespace-nowrap flex-1 justify-center"
              style={active ? { background: "#0F513215", color: "#0F5132" } : { color: "#6b7280" }}>
              <tab.icon className="w-4 h-4 shrink-0" />
              <span className="hidden sm:inline">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ── PERFIL ── */}
      {activeTab === "perfil" && (
        <div className="space-y-6">
          <SectionCard title="Foto de perfil" description="Esta imagem será exibida no seu painel e em relatórios.">
            <div className="flex items-center gap-6">
              <div className="relative">
                {profile.photoUrl ? (
                  <img src={profile.photoUrl} alt="Foto" className="w-20 h-20 rounded-full object-cover ring-4"
                    style={{ ringColor: "#0F513230" }} />
                ) : (
                  <div className="w-20 h-20 rounded-full flex items-center justify-center text-2xl font-bold text-white"
                    style={{ background: "#0F5132" }}>
                    {initials}
                  </div>
                )}
              </div>
              <div className="flex flex-col gap-2">
                <button onClick={() => fileRef.current?.click()}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl border text-sm font-medium hover:bg-gray-50 transition-colors">
                  <Camera className="w-4 h-4" /> Alterar foto
                </button>
                <button onClick={() => setField("photoUrl", "")} disabled={!profile.photoUrl}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl border text-sm text-red-500 hover:bg-red-50 transition-colors disabled:opacity-40">
                  <Trash2 className="w-4 h-4" /> Remover
                </button>
                <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handlePhoto} />
              </div>
              {/* Preview rápido */}
              <div className="ml-auto hidden md:flex flex-col items-end text-right">
                <p className="font-semibold text-gray-900">{profile.firstName} {profile.lastName}</p>
                <p className="text-sm text-gray-500">{profile.email}</p>
                <p className="text-xs mt-1 px-2 py-0.5 rounded-full font-medium"
                  style={{ background: "#0F513215", color: "#0F5132" }}>{profile.role}</p>
              </div>
            </div>
          </SectionCard>

          <SectionCard title="Informações pessoais" description="Seus dados básicos de identificação na plataforma.">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { label: "Nome", field: "firstName" as const, placeholder: "Seu nome" },
                { label: "Sobrenome", field: "lastName" as const, placeholder: "Seu sobrenome" },
              ].map(({ label, field, placeholder }) => (
                <div key={field}>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">{label}</label>
                  <input value={profile[field]} onChange={e => setField(field, e.target.value)} placeholder={placeholder}
                    className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 transition-shadow"
                    style={{ "--tw-ring-color": "#0F513240" } as React.CSSProperties} />
                </div>
              ))}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1.5">E-mail</label>
                <input value={profile.email} onChange={e => setField("email", e.target.value)} type="email"
                  className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 transition-shadow" />
              </div>
              {[
                { label: "Cargo / Função", field: "role" as const, placeholder: "Analista Ambiental" },
                { label: "Telefone", field: "phone" as const, placeholder: "+55 61 9 0000-0000" },
                { label: "Organização", field: "organization" as const, placeholder: "CERES AI" },
                { label: "Estado (UF)", field: "state" as const, placeholder: "DF" },
              ].map(({ label, field, placeholder }) => (
                <div key={field}>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">{label}</label>
                  <input value={profile[field]} onChange={e => setField(field, e.target.value)} placeholder={placeholder}
                    className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 transition-shadow" />
                </div>
              ))}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Biografia</label>
                <textarea value={profile.bio} onChange={e => setField("bio", e.target.value)}
                  rows={3} placeholder="Conte um pouco sobre você e sua atuação no campo ambiental..."
                  className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 resize-none transition-shadow" />
              </div>
            </div>
          </SectionCard>

          <div className="flex justify-end gap-3">
            <button onClick={handleDiscard} disabled={!dirty}
              className="px-5 py-2.5 rounded-xl border text-sm font-medium text-gray-600 hover:bg-gray-50 disabled:opacity-40 transition-colors">
              Descartar
            </button>
            <button onClick={handleSaveProfile} disabled={!dirty}
              className="px-5 py-2.5 rounded-xl text-white text-sm font-semibold disabled:opacity-40 transition-colors"
              style={{ background: "#0F5132" }}>
              Salvar alterações
            </button>
          </div>
        </div>
      )}

      {/* ── NOTIFICAÇÕES ── */}
      {activeTab === "notificacoes" && (
        <div className="space-y-6">
          {[
            {
              title: "E-mail", icon: Mail, description: "Receba atualizações importantes por e-mail.",
              items: [
                { key: "emailAlerts" as const, label: "Alertas críticos", sub: "Focos de calor, desmatamento detectado" },
                { key: "emailReports" as const, label: "Relatórios gerados", sub: "Notificação quando um relatório estiver pronto" },
                { key: "emailUpdates" as const, label: "Novidades da plataforma", sub: "Novas funcionalidades e melhorias" },
              ]
            },
            {
              title: "Push / Navegador", icon: Globe, description: "Notificações em tempo real no navegador.",
              items: [
                { key: "pushAlerts" as const, label: "Alertas ambientais", sub: "Notificações imediatas de eventos críticos" },
                { key: "pushReminders" as const, label: "Lembretes de pendências CAR", sub: "Prazos e pendências cadastrais" },
              ]
            },
            {
              title: "SMS", icon: MessageSquare, description: "Mensagens de texto para alertas urgentes.",
              items: [
                { key: "smsAlerts" as const, label: "Alertas de emergência", sub: "Apenas para situações críticas" },
              ]
            },
            {
              title: "Resumos", icon: Bell, description: "Relatórios periódicos sobre sua propriedade.",
              items: [
                { key: "weeklyDigest" as const, label: "Resumo semanal", sub: "Panorama da semana por e-mail" },
                { key: "monthlyReport" as const, label: "Relatório mensal", sub: "Evolução mensal da regularização CAR" },
              ]
            },
          ].map(group => (
            <SectionCard key={group.title} title={group.title} description={group.description}>
              <div className="space-y-4">
                {group.items.map(item => (
                  <div key={item.key} className="flex items-center justify-between py-1">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{item.label}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{item.sub}</p>
                    </div>
                    <Toggle checked={notif[item.key]} onChange={() => toggleNotif(item.key)} />
                  </div>
                ))}
              </div>
            </SectionCard>
          ))}
        </div>
      )}

      {/* ── APARÊNCIA ── */}
      {activeTab === "aparencia" && (
        <div className="space-y-6">
          <SectionCard title="Tema" description="Escolha a aparência visual da plataforma.">
            <div className="grid grid-cols-3 gap-3">
              {([
                { id: "light", icon: Sun, label: "Claro" },
                { id: "dark", icon: Moon, label: "Escuro" },
                { id: "system", icon: Monitor, label: "Sistema" },
              ] as const).map(opt => (
                <button key={opt.id} onClick={() => setAppearField("theme", opt.id)}
                  className="flex flex-col items-center gap-2 p-4 rounded-xl border-2 text-sm font-medium transition-all"
                  style={appear.theme === opt.id
                    ? { borderColor: "#0F5132", background: "#0F513210", color: "#0F5132" }
                    : { borderColor: "#e5e7eb", color: "#6b7280" }}>
                  <opt.icon className="w-5 h-5" />
                  {opt.label}
                </button>
              ))}
            </div>
          </SectionCard>

          <SectionCard title="Densidade" description="Ajuste o espaçamento da interface.">
            <div className="grid grid-cols-3 gap-3">
              {(["compact", "normal", "spacious"] as const).map(d => (
                <button key={d} onClick={() => setAppearField("density", d)}
                  className="p-3 rounded-xl border-2 text-sm font-medium capitalize transition-all"
                  style={appear.density === d
                    ? { borderColor: "#0F5132", background: "#0F513210", color: "#0F5132" }
                    : { borderColor: "#e5e7eb", color: "#6b7280" }}>
                  {d === "compact" ? "Compacto" : d === "normal" ? "Normal" : "Espaçoso"}
                </button>
              ))}
            </div>
          </SectionCard>

          <SectionCard title="Localização" description="Idioma, fuso horário e formato de data.">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {[
                { label: "Idioma", field: "language" as const, options: [{ v: "pt-BR", l: "Português (Brasil)" }, { v: "en-US", l: "English (US)" }, { v: "es", l: "Español" }] },
                { label: "Formato de data", field: "dateFormat" as const, options: [{ v: "dd/MM/yyyy", l: "DD/MM/AAAA" }, { v: "MM/dd/yyyy", l: "MM/DD/YYYY" }, { v: "yyyy-MM-dd", l: "AAAA-MM-DD" }] },
                { label: "Fuso horário", field: "timezone" as const, options: [{ v: "America/Sao_Paulo", l: "Brasília (GMT-3)" }, { v: "America/Manaus", l: "Manaus (GMT-4)" }, { v: "America/Belem", l: "Belém (GMT-3)" }] },
              ].map(({ label, field, options }) => (
                <div key={field}>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">{label}</label>
                  <select value={appear[field] as string} onChange={e => setAppearField(field, e.target.value as AppearSettings[typeof field])}
                    className="w-full px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none bg-white">
                    {options.map(o => <option key={o.v} value={o.v}>{o.l}</option>)}
                  </select>
                </div>
              ))}
            </div>
          </SectionCard>
        </div>
      )}

      {/* ── SEGURANÇA ── */}
      {activeTab === "seguranca" && (
        <div className="space-y-6">
          <SectionCard title="Alterar senha" description="Use uma senha forte e única para esta conta.">
            <div className="space-y-4 max-w-md">
              {[
                { label: "Senha atual", value: currentPw, setter: setCurrentPw, show: showCurrent, toggle: setShowCurrent },
                { label: "Nova senha", value: newPw, setter: setNewPw, show: showNew, toggle: setShowNew },
                { label: "Confirmar nova senha", value: confirmPw, setter: setConfirmPw, show: showConfirm, toggle: setShowConfirm },
              ].map(({ label, value, setter, show, toggle }) => (
                <div key={label}>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">{label}</label>
                  <div className="relative">
                    <input type={show ? "text" : "password"} value={value} onChange={e => setter(e.target.value)}
                      className="w-full px-3 py-2 pr-10 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 transition-shadow" />
                    <button type="button" onClick={() => toggle(!show)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                      {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {label === "Nova senha" && newPw && (
                    <div className="mt-2 space-y-1">
                      <div className="flex gap-1">
                        {[0, 1, 2, 3].map(i => (
                          <div key={i} className="h-1.5 flex-1 rounded-full transition-colors"
                            style={{ background: i < strength.score ? strength.color : "#e5e7eb" }} />
                        ))}
                      </div>
                      <p className="text-xs font-medium" style={{ color: strength.color }}>{strength.label}</p>
                    </div>
                  )}
                  {label === "Confirmar nova senha" && confirmPw && newPw !== confirmPw && (
                    <p className="text-xs text-red-500 mt-1">As senhas não coincidem</p>
                  )}
                </div>
              ))}
              <button onClick={handleChangePassword}
                className="w-full py-2.5 rounded-xl text-white text-sm font-semibold transition-colors"
                style={{ background: "#0F5132" }}>
                Alterar senha
              </button>
            </div>
          </SectionCard>

          <SectionCard title="Autenticação de dois fatores" description="Adicione uma camada extra de segurança à sua conta.">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: "#0F513215" }}>
                <Smartphone className="w-6 h-6" style={{ color: "#0F5132" }} />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900">Autenticador por aplicativo</p>
                <p className="text-xs text-gray-500">Use Google Authenticator, Authy ou similar.</p>
              </div>
              <button className="px-4 py-2 rounded-xl border text-sm font-medium hover:bg-gray-50 transition-colors">
                Configurar
              </button>
            </div>
          </SectionCard>

          <SectionCard title="Sessões ativas" description="Dispositivos com acesso à sua conta.">
            <div className="space-y-3">
              {[
                { device: "Chrome — Windows 11", location: "Brasília, DF", time: "Agora", current: true },
                { device: "Firefox — macOS", location: "São Paulo, SP", time: "há 2 dias", current: false },
              ].map((s, i) => (
                <div key={i} className="flex items-center justify-between py-3 border-b border-gray-50 last:border-0">
                  <div>
                    <p className="text-sm font-medium text-gray-900 flex items-center gap-2">
                      {s.device}
                      {s.current && (
                        <span className="text-xs px-2 py-0.5 rounded-full font-semibold"
                          style={{ background: "#0F513215", color: "#0F5132" }}>Atual</span>
                      )}
                    </p>
                    <p className="text-xs text-gray-500">{s.location} · {s.time}</p>
                  </div>
                  {!s.current && (
                    <button className="text-xs text-red-500 hover:text-red-700 font-medium transition-colors">
                      Encerrar
                    </button>
                  )}
                </div>
              ))}
            </div>
          </SectionCard>

          <SectionCard title="Zona de perigo">
            <div className="space-y-3">
              <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-orange-200 bg-orange-50 text-orange-700 hover:bg-orange-100 transition-colors text-sm font-medium">
                <Download className="w-4 h-4" />
                Exportar meus dados
              </button>
              <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 transition-colors text-sm font-medium">
                <AlertTriangle className="w-4 h-4" />
                Encerrar conta permanentemente
              </button>
            </div>
          </SectionCard>
        </div>
      )}

      {/* ── INTEGRAÇÕES ── */}
      {activeTab === "integracoes" && (
        <div className="space-y-6">
          {/* Integrações externas */}
          <SectionCard title="Serviços conectados" description="Conecte o CERES AI a outras ferramentas que você usa.">
            <div className="space-y-4">
              {[
                {
                  name: "Slack", icon: "💬", desc: "Receba alertas e relatórios no seu workspace.",
                  connected: slackConnected,
                  toggle: () => { const n = !slackConnected; setSlackConnected(n); save("ceres:slack", n); toast({ title: n ? "Slack conectado" : "Slack desconectado" }); }
                },
                {
                  name: "Google Sheets", icon: "📊", desc: "Exporte dados de monitoramento automaticamente.",
                  connected: sheetsConnected,
                  toggle: () => { const n = !sheetsConnected; setSheetsConnected(n); save("ceres:sheets", n); toast({ title: n ? "Sheets conectado" : "Sheets desconectado" }); }
                },
              ].map(svc => (
                <div key={svc.name} className="flex items-center gap-4 py-3 border-b border-gray-50 last:border-0">
                  <div className="w-10 h-10 rounded-xl bg-gray-50 flex items-center justify-center text-xl">{svc.icon}</div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-gray-900">{svc.name}</p>
                    <p className="text-xs text-gray-500">{svc.desc}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    {svc.connected && (
                      <span className="text-xs px-2 py-0.5 rounded-full font-medium"
                        style={{ background: "#0F513215", color: "#0F5132" }}>Conectado</span>
                    )}
                    <button onClick={svc.toggle}
                      className="px-3 py-1.5 rounded-xl border text-sm font-medium transition-colors hover:bg-gray-50"
                      style={svc.connected ? { borderColor: "#fca5a5", color: "#ef4444" } : {}}>
                      {svc.connected ? "Desconectar" : "Conectar"}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </SectionCard>

          {/* Webhook */}
          <SectionCard title="Webhook" description="Receba eventos do CERES AI em seu sistema via HTTP POST.">
            <div className="flex gap-2">
              <input value={webhook} onChange={e => setWebhook(e.target.value)}
                placeholder="https://seu-sistema.com/webhook/ceres"
                className="flex-1 px-3 py-2 rounded-xl border border-gray-200 text-sm focus:outline-none" />
              <button onClick={saveWebhook}
                className="px-4 py-2 rounded-xl text-white text-sm font-medium transition-colors"
                style={{ background: "#0F5132" }}>
                Salvar
              </button>
            </div>
          </SectionCard>

          {/* API Key */}
          <SectionCard title="Chave de API" description="Use esta chave para acessar a API do CERES AI programaticamente.">
            <div className="space-y-3">
              <div className="flex gap-2">
                <code className="flex-1 px-3 py-2 rounded-xl bg-gray-50 border border-gray-200 text-sm font-mono text-gray-700 truncate">
                  {apiKey}
                </code>
                <button onClick={copyApiKey}
                  className="px-3 py-2 rounded-xl border hover:bg-gray-50 transition-colors" title="Copiar">
                  <Copy className="w-4 h-4 text-gray-500" />
                </button>
                <button onClick={regenApiKey}
                  className="px-3 py-2 rounded-xl border hover:bg-gray-50 transition-colors" title="Regenerar">
                  <RefreshCw className="w-4 h-4 text-gray-500" />
                </button>
              </div>
              <p className="text-xs text-amber-600 flex items-center gap-1.5">
                <KeyRound className="w-3.5 h-3.5" />
                Nunca compartilhe sua chave de API. Regenere-a se suspeitar de comprometimento.
              </p>
            </div>
          </SectionCard>
        </div>
      )}
    </Layout>
  );
}
